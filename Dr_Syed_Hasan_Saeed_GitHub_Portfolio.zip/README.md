# Dr. Syed Hasan Saeed - Academic Portfolio

Files:
- `index.html` - website structure and content
- `style.css` - responsive design and theme
- `script.js` - publication filtering, navigation, theme toggle and interactions
- `CV_Syed_Hasan_Saeed_2024.doc` - CV download used by the website

## GitHub Pages
1. Create a GitHub repository, for example `syed-hasan-saeed-portfolio`.
2. Upload all files from this folder to the repository root.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will provide the published website URL.

The site uses no build step. It is plain HTML, CSS and JavaScript and can be hosted directly on GitHub Pages.
