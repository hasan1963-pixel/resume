const publications = [
{y:2024,t:"Design and Performance Analysis of a Low Jitter Charge Pump-Phase Locked Loop Architecture and Loop Filter in CMOS Process",j:"Journal of Electrical Systems",d:"DOI: 10.52783/jes.5397",tag:"SCOPUS"},
{y:2024,t:"A low leakage and high-speed phase frequency detector-charge pump designed in nano dimension-based CMOS technology",j:"Journal of Nano- and Electronic Physics",d:"DOI: 10.57647/j.ijnd.2024.1504.29",tag:"ESCI"},
{y:2023,t:"Harmful gases detection using artificial neural networks of the environment",j:"International Journal of Electrical and Computer Engineering",d:"Vol. 30, pp. 1389–1398",tag:""},
{y:2023,t:"Toxic gases detection using PARAFAC and PCA to protect the environment",j:"Materials Today: Proceedings",d:"DOI: 10.1016/j.matpr.2023.03.360",tag:""},
{y:2023,t:"Detection of harmful gases present in the environment",j:"Indonesian Journal of Electrical Engineering and Computer Science",d:"Vol. 30, No. 1, pp. 70–80",tag:""},
{y:2022,t:"Charge Pump-Phase Frequency Detector based Phase-Locked Loop for Modern Wireless Communication—A Review",j:"Proceedings of Trends in Electronics and Health Informatics, Springer",d:"DOI: 10.1007/978-981-16-8826-3_42",tag:"SCOPUS"},
{y:2021,t:"Optimization and sizing of SPV/Wind hybrid renewable energy system: a techno-economic and social perspective",j:"Energy, Elsevier",d:"Vol. 233, 121114. DOI: 10.1016/j.energy.2021.121114",tag:"SCIE • Q1"},
{y:2021,t:"Effect of annealing temperature on a highly sensitive nickel oxide-based LPG sensor operated at room temperature",j:"Applied Physics A",d:"2021, 127:289. DOI: 10.1007/s0039-021-0000-6",tag:"SCIE"},
{y:2019,t:"Optimization of electronic sensors for distinguishing contamination because of solid waste gases",j:"International Journal of Electrical and Computer Engineering",d:"Vol. 09, Issue 5",tag:""},
{y:2019,t:"A Review on Optimization of Electronic Sensors for Detecting Pollution Due to Solid Waste Gases",j:"JETIR",d:"Volume 6, Issue 3, pp. 439–445",tag:""},
{y:2019,t:"Simulation and Optimization of Artificial Neural Network Based Air Quality Estimator",j:"International Journal of Recent Technology and Engineering",d:"Volume 8, Issue 3. DOI: 10.35940/ijrte.C4985.098319",tag:"SCOPUS"},
{y:2020,t:"Simulation and optimization of genetic algorithm-artificial neural network based air quality estimator",j:"Indonesian Journal of Electrical Engineering and Computer Science",d:"Vol. 19, No. 2, pp. 775–783. DOI: 10.11591/ijeecs.v19.i2.pp775-783",tag:"SCOPUS"},
{y:2020,t:"Localization based Energy Optimization in Heterogeneous Wireless Sensor Network",j:"International journal publication",d:"Vol. 29, No. 8, pp. 4877–4886",tag:"SCOPUS"},
{y:2020,t:"A New Strategy Adopted to Save Energy to Localization a Moving Objects in WSN",j:"International Journal of Emerging Trends in Engineering Research",d:"Vol. 8, No. 4. DOI: 10.30534/ijeter/2020/7982020",tag:"SCOPUS"},
{y:2018,t:"Environment Monitoring Using Electronic Sensors For Detecting Pollution Due To Solid Waste Gases Using Five Sensors",j:"IOSR Journal of Engineering",d:"Vol. 08, Issue 7, pp. 42–49",tag:"SCOPUS"},
{y:2018,t:"Review of solar photovoltaic and wind hybrid energy systems for sizing strategies optimization techniques and cost analysis methodologies",j:"Renewable and Sustainable Energy Reviews, Elsevier",d:"Vol. 92, pp. 937–947. DOI: 10.1016/j.rser.2018.04.107",tag:"SCIE • Q1"},
{y:2017,t:"A review on gas sensors for environment monitoring using electronic sensors for detecting pollution due to solid waste gases",j:"International Journal of Engineering Research and General Science",d:"Volume 5, Issue 5",tag:"SCOPUS"},
{y:2017,t:"A Survey on Leach Based Protocols in Wireless Sensor Network",j:"International Journal of Emerging Technology and Advanced Engineering",d:"Vol. 7, Issue 7",tag:""},
{y:2016,t:"A Survey on Early Detection of Critical Diseases by Human Breath Analysis",j:"International Journal of Advanced Research in Electrical, Electronics and Instrumentation Engineering",d:"Vol. 5, Issue 6",tag:""},
{y:2015,t:"Design of Affordable and Effectual DIY Solar Kit",j:"International Journal of Engineering Trends and Technology",d:"Vol. 21, No. 1",tag:""},
{y:2015,t:"A Comprehensive Study of Various on Demand Routing Protocols in MANETs",j:"International Journal of Electronics and Communication Engineering",d:"Vol. 4, Issue 2",tag:""},
{y:2014,t:"Design of Floating Multiplier Using Vedic Aphorisms",j:"International Journal of Engineering Trends and Technology",d:"Vol. 11, No. 3",tag:""},
{y:2014,t:"Implementation of Fuzzy Logic Controller for Speed Control of Motor using VHDL",j:"International Journal of Engineering Trends and Technology",d:"Vol. 11, No. 3",tag:""},
{y:2014,t:"Implementation of Switching System for High Speed Data Transmission using VHDL",j:"International Journal of Engineering Trends and Technology",d:"Vol. 11, No. 3",tag:""},
{y:2014,t:"MIMO System Performance Evaluation High Data Rate Wireless Networks using Space Time Block Codes",j:"International Journal of Modern Engineering Research",d:"Vol. 4, Issue 6",tag:""},
{y:2013,t:"Modern Applications of Electronic Nose: A Review",j:"International Journal of Electrical and Computer Engineering",d:"Vol. 3, No. 1, pp. 52–63",tag:""},
{y:2013,t:"Developments In Electronic Nose Systems",j:"IJECIERD",d:"Vol. 3, Issue 4, pp. 105–112",tag:""},
{y:2013,t:"EEG Signals Play Major Role To Diagnose Sleep Disorder",j:"International Journal of Electronics and Computer Science Engineering",d:"Published March 2013",tag:""},
{y:2013,t:"Review of Electronic Nose and Applications",j:"International Journal of Computing and Corporate Research",d:"Vol. 3, Issue 2",tag:""},
{y:2012,t:"Electronic Nose in Food and Health Applications: A Review",j:"International Journal of Computing and Corporate Research",d:"Vol. 2, Issue 6",tag:""},
{y:2009,t:"Study of TGS 822 Sensor for Electronic Nose Applications",j:"MASAUM Journal of Basic and Applied Sciences",d:"Vol. 1, No. 2, pp. 260–264",tag:""}
];

const list = document.getElementById("publicationList");
const search = document.getElementById("pubSearch");
const year = document.getElementById("pubYear");
const loadMore = document.getElementById("loadMore");
let visible = 8;

[...new Set(publications.map(p=>p.y))].sort((a,b)=>b-a).forEach(y=>{
  const o=document.createElement("option"); o.value=y; o.textContent=y; year.appendChild(o);
});

function render(){
  const q=search.value.toLowerCase().trim(), yr=year.value;
  const filtered=publications.filter(p=>(yr==="all"||String(p.y)===yr)&&`${p.t} ${p.j} ${p.d} ${p.tag}`.toLowerCase().includes(q));
  list.innerHTML=filtered.slice(0,visible).map(p=>`
    <article class="publication">
      <span class="pub-year">${p.y}</span>
      <h3>${p.t}</h3>
      <p><strong>${p.j}</strong> · ${p.d}${p.tag?` · <strong>${p.tag}</strong>`:""}</p>
    </article>`).join("");
  loadMore.style.display=filtered.length>visible?"block":"none";
}
search.addEventListener("input",()=>{visible=8;render()});
year.addEventListener("change",()=>{visible=8;render()});
loadMore.addEventListener("click",()=>{visible+=8;render()});
render();

document.getElementById("year").textContent=new Date().getFullYear();

const menuToggle=document.getElementById("menuToggle"), nav=document.getElementById("navLinks");
menuToggle.addEventListener("click",()=>nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const theme=document.getElementById("themeToggle");
if(localStorage.getItem("theme")==="dark") document.body.classList.add("dark");
function updateThemeIcon(){theme.textContent=document.body.classList.contains("dark")?"☀":"☾"}
updateThemeIcon();
theme.addEventListener("click",()=>{
  document.body.classList.toggle("dark");
  localStorage.setItem("theme",document.body.classList.contains("dark")?"dark":"light");
  updateThemeIcon();
});

const observer=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting)e.target.style.animationPlayState="running"});
},{threshold:.08});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));
